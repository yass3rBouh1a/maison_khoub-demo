import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Collections } from './components/Collections';
import { ProductGrid } from './components/ProductGrid';
import { SavoirFaire } from './components/SavoirFaire';
import { ProductPage } from './components/ProductPage';
import { UpsellModal } from './components/UpsellModal';
import { Product } from './components/ProductCard';

// Mock Products Data
const products: Product[] = [
  {
    id: '1',
    name: 'Kaftan Royal',
    price: 2500,
    image: 'https://images.unsplash.com/photo-1590056773301-38a61f70b7cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBtb3JvY2NhbiUyMGthZnRhbiUyMGZhc2hpb24lMjBlZGl0b3JpYWx8ZW58MXx8fHwxNzcwNzQ4NDIyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Kaftans'
  },
  {
    id: '2',
    name: 'Djellaba Élégante',
    price: 1800,
    image: 'https://images.unsplash.com/photo-1762782777495-9d297f3d9d3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwbW9yb2NjYW4lMjBkamVsbGabiYSUyMHRyYWRpdGlvbmFsfGVufDF8fHx8MTc3MDc0ODQyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Djellabas'
  },
  {
    id: '3',
    name: 'Caftan Brodé',
    price: 3200,
    image: 'https://images.unsplash.com/photo-1616089180418-56172f6c3c2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3JvY2NhbiUyMGx1eHVyeSUyMHRleHRpbGUlMjBjcmFmdHNtYW5zaGlwfGVufDF8fHx8MTc3MDc0ODQyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Kaftans'
  },
  {
    id: '4',
    name: 'Robe Signature',
    price: 2800,
    image: 'https://images.unsplash.com/photo-1768124161461-da746ceb5626?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbW9kZWwlMjBlbGVnYW50JTIwZHJlc3MlMjBlZGl0b3JpYWx8ZW58MXx8fHwxNzcwNzQ4NDI0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Robes'
  }
];

// Upsell Product
const upsellProduct: Product = {
  id: '5',
  name: 'Ceinture Artisanale',
  price: 450,
  image: 'https://images.unsplash.com/photo-1732139637218-ef33b3339dfc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBmYXNoaW9uJTIwYWNjZXNzb3JpZXMlMjBiZWx0JTIwZ29sZHxlbnwxfHx8fDE3NzA3NDg0MjR8MA&ixlib=rb-4.1.0&q=80&w=1080',
  category: 'Accessoires'
};

function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showUpsellModal, setShowUpsellModal] = useState(false);
  const [cartItems, setCartItems] = useState<Array<{ product: Product; size: string }>>([]);
  const [showHomepage, setShowHomepage] = useState(true);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setShowHomepage(false);
  };

  const handleCloseProductPage = () => {
    setSelectedProduct(null);
    setShowHomepage(true);
  };

  const handleAddToCart = (product: Product, size: string) => {
    // Show upsell modal after adding to cart
    setCartItems([...cartItems, { product, size }]);
    setShowUpsellModal(true);
  };

  const handleAddUpsell = (product: Product) => {
    setCartItems([...cartItems, { product, size: 'Universal' }]);
    setShowUpsellModal(false);
    setSelectedProduct(null);
    setShowHomepage(true);
  };

  const handleDeclineUpsell = () => {
    setShowUpsellModal(false);
    setSelectedProduct(null);
    setShowHomepage(true);
  };

  const scrollToProducts = () => {
    const productsSection = document.getElementById('products');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      <Header cartItemsCount={cartItems.length} />

      {showHomepage && (
        <>
          <Hero onCTAClick={scrollToProducts} />
          <Collections />
          <SavoirFaire />
          <div id="products">
            <ProductGrid 
              products={products} 
              onProductClick={handleProductClick}
            />
          </div>
        </>
      )}

      {selectedProduct && (
        <ProductPage
          product={selectedProduct}
          onClose={handleCloseProductPage}
          onAddToCart={handleAddToCart}
        />
      )}

      <UpsellModal
        isOpen={showUpsellModal}
        onClose={() => setShowUpsellModal(false)}
        upsellProduct={upsellProduct}
        onAddUpsell={handleAddUpsell}
        onDecline={handleDeclineUpsell}
      />
    </div>
  );
}

export default App;