import { ProductCard, Product } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  onProductClick?: (product: Product) => void;
}

export function ProductGrid({ products, onProductClick }: ProductGridProps) {
  return (
    <section className="bg-[#FAFAFA] py-24 px-8">
      <div className="container mx-auto max-w-[1400px]">
        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-20">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onClick={() => onProductClick?.(product)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
