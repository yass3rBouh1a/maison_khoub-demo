interface Collection {
  id: string;
  name: string;
  description: string;
  image: string;
}

const collections: Collection[] = [
  {
    id: '1',
    name: 'Kaftans Haute Couture',
    description: 'Pièces royales brodées à la main',
    image: 'https://images.unsplash.com/photo-1626412738528-a88a82060e41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBtb3JvY2NhbiUyMGthZnRhbiUyMGhhdXRlJTIwY291dHVyZSUyMGVkaXRvcmlhbHxlbnwxfHx8fDE3NzA3NTAwMTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    name: 'Djellabas Modernes',
    description: 'Coupes fluides et élégance décontractée',
    image: 'https://images.unsplash.com/photo-1762782777495-9d297f3d9d3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZGplbGxhYmElMjBtb2Rlcm4lMjBmYXNoaW9uJTIwbW9kZWx8ZW58MXx8fHwxNzcwNzUwMDE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '3',
    name: 'Collection Liberty',
    description: 'Cottons Liberty London – Motifs floraux exclusifs',
    image: 'https://images.unsplash.com/photo-1625997019230-45e7dca6bba0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWJlcnR5JTIwbG9uZG9uJTIwZmxvcmFsJTIwZmFicmljJTIwdGV4dGlsZXxlbnwxfHx8fDE3NzA3NTAwMTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '4',
    name: 'Créations Signature',
    description: 'Robes uniques, pièces d\'exception',
    image: 'https://images.unsplash.com/photo-1622079401116-8317808352d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaWduYXR1cmUlMjBlbGVnYW50JTIwZHJlc3MlMjBmYXNoaW9uJTIwZWRpdG9yaWFsfGVufDF8fHx8MTc3MDc1MDAxOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export function Collections() {
  return (
    <section className="bg-[#FAFAFA] py-24 px-8">
      <div className="container mx-auto max-w-[1400px]">
        {/* Section Title */}
        <div className="text-center mb-20">
          <h2 
            className="text-[#1A1A1A] mb-4"
            style={{ 
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(32px, 4vw, 48px)',
              fontWeight: 400,
              letterSpacing: '0.02em',
              lineHeight: 1.3
            }}
          >
            Nos Collections
          </h2>
          <p 
            className="text-[#595959] text-[14px] tracking-wide uppercase"
            style={{ fontFamily: 'Lato, sans-serif' }}
          >
            Quatre univers de luxe marocain
          </p>
        </div>

        {/* Collections Grid - 2x2 Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {collections.map((collection) => (
            <div 
              key={collection.id}
              className="group relative overflow-hidden bg-white cursor-pointer"
              style={{ aspectRatio: '4/5' }}
            >
              {/* Image */}
              <div className="absolute inset-0 overflow-hidden">
                <img
                  src={collection.image}
                  alt={collection.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors duration-300" />
              </div>

              {/* Content */}
              <div className="absolute inset-0 flex flex-col justify-end p-12">
                <h3 
                  className="text-white mb-2"
                  style={{ 
                    fontFamily: 'Playfair Display, serif',
                    fontSize: 'clamp(24px, 3vw, 32px)',
                    fontWeight: 400,
                    letterSpacing: '0.02em'
                  }}
                >
                  {collection.name}
                </h3>
                <p 
                  className="text-white/90 mb-6"
                  style={{ 
                    fontFamily: 'Lato, sans-serif',
                    fontSize: '13px',
                    fontWeight: 300,
                    letterSpacing: '0.05em'
                  }}
                >
                  {collection.description}
                </p>

                {/* CTA */}
                <div className="flex items-center gap-3 text-white group-hover:gap-5 transition-all duration-300">
                  <span 
                    className="text-[12px] tracking-[0.15em] uppercase"
                    style={{ fontFamily: 'Lato, sans-serif' }}
                  >
                    Explorer
                  </span>
                  <div className="w-8 h-[1px] bg-white" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
