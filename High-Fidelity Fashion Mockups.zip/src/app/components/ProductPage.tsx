import { X } from 'lucide-react';
import { useState } from 'react';
import { Product } from './ProductCard';

interface ProductPageProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, size: string) => void;
}

const sizes = ['XS', 'S', 'M', 'L', 'XL'];

export function ProductPage({ product, onClose, onAddToCart }: ProductPageProps) {
  const [selectedSize, setSelectedSize] = useState('M');

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize);
  };

  return (
    <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
      {/* Close Button */}
      <button
        onClick={onClose}
        className="fixed top-8 right-8 z-10 group"
        aria-label="Close"
      >
        <X 
          size={24} 
          strokeWidth={1} 
          className="text-[#1A1A1A] transition-opacity group-hover:opacity-60"
        />
      </button>

      {/* Split Screen Layout */}
      <div className="min-h-screen flex flex-col lg:flex-row">
        {/* Left: Image */}
        <div className="w-full lg:w-1/2 lg:sticky lg:top-0 h-[60vh] lg:h-screen bg-[#F5F5F5]">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Right: Product Info */}
        <div className="w-full lg:w-1/2 p-8 lg:p-16 flex items-center">
          <div className="max-w-[600px] mx-auto w-full">
            {/* Product Name */}
            <h1 
              className="text-[#1A1A1A] mb-6"
              style={{ 
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(32px, 4vw, 48px)',
                fontWeight: 400,
                letterSpacing: '0.01em',
                lineHeight: 1.2
              }}
            >
              {product.name}
            </h1>

            {/* Price */}
            <p 
              className="text-[#96754a] mb-12"
              style={{ 
                fontFamily: 'Lato, sans-serif',
                fontSize: '20px',
                fontWeight: 400
              }}
            >
              {product.price.toLocaleString('fr-MA')} MAD
            </p>

            {/* Description */}
            <p 
              className="text-[#595959] mb-12 leading-relaxed"
              style={{ 
                fontFamily: 'Lato, sans-serif',
                fontSize: '15px',
                fontWeight: 300,
                lineHeight: 1.8
              }}
            >
              Confectionné à la main par nos artisans marocains, ce kaftan incarne l'élégance 
              intemporelle. Réalisé dans un tissu noble et orné de détails subtils, 
              cette pièce unique allie tradition et raffinement contemporain.
            </p>

            {/* Size Selector */}
            <div className="mb-12">
              <p 
                className="text-[#1A1A1A] mb-4"
                style={{ 
                  fontFamily: 'Lato, sans-serif',
                  fontSize: '13px',
                  fontWeight: 400,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase'
                }}
              >
                Taille
              </p>
              <div className="flex gap-3">
                {sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-14 h-14 border transition-all ${
                      selectedSize === size
                        ? 'border-[#96754a] bg-[#96754a] text-white'
                        : 'border-[#E0E0E0] bg-white text-[#1A1A1A] hover:border-[#96754a]'
                    }`}
                    style={{ 
                      fontFamily: 'Lato, sans-serif',
                      fontSize: '13px',
                      fontWeight: 400
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Add to Cart Button */}
            <button
              onClick={handleAddToCart}
              className="w-full py-5 bg-[#96754a] text-white hover:bg-[#7d6240] transition-colors mb-6"
              style={{ 
                fontFamily: 'Lato, sans-serif',
                fontSize: '13px',
                fontWeight: 400,
                letterSpacing: '0.15em',
                textTransform: 'uppercase'
              }}
            >
              Ajouter au Panier
            </button>

            {/* Legal Notice */}
            <p 
              className="text-[#999999] text-center"
              style={{ 
                fontFamily: 'Lato, sans-serif',
                fontSize: '11px',
                fontWeight: 300,
                lineHeight: 1.6
              }}
            >
              Pas de retour ni échange • Livraison internationale disponible
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
