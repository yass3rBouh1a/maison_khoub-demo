import { Menu, Search, ShoppingBag, User } from 'lucide-react';
import { useState, useEffect } from 'react';
import logoImage from 'figma:asset/13fdb096ea7d319aa25e7e66eaab5ada24261745.png';

interface HeaderProps {
  onMenuClick?: () => void;
  cartItemsCount?: number;
}

export function Header({ onMenuClick, cartItemsCount = 0 }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white shadow-sm' 
          : 'bg-white/10 backdrop-blur-md'
      }`}
    >
      <div className="container mx-auto px-8">
        <div className="flex items-center justify-between h-20">
          {/* Left: Menu & Search */}
          <div className="flex items-center gap-8">
            <button
              onClick={onMenuClick}
              className="group"
              aria-label="Menu"
            >
              <Menu 
                size={20} 
                strokeWidth={1} 
                className={`transition-all duration-300 group-hover:opacity-60 ${
                  isScrolled ? 'text-[#1A1A1A]' : 'text-white'
                }`}
              />
            </button>
            <button className="group" aria-label="Search">
              <Search 
                size={20} 
                strokeWidth={1} 
                className={`transition-all duration-300 group-hover:opacity-60 ${
                  isScrolled ? 'text-[#1A1A1A]' : 'text-white'
                }`}
              />
            </button>
          </div>

          {/* Center: Logo */}
          <div className="absolute left-1/2 transform -translate-x-1/2">
            <img
              src={logoImage}
              alt="KHOUB Maison"
              className="h-24 w-auto transition-all duration-300"
              style={{ filter: isScrolled ? 'none' : 'brightness(0) invert(1)' }}
            />
          </div>

          {/* Right: Account & Cart */}
          <div className="flex items-center gap-8">
            <button className="group flex items-center gap-2" aria-label="Account">
              <User 
                size={20} 
                strokeWidth={1} 
                className={`transition-all duration-300 group-hover:opacity-60 ${
                  isScrolled ? 'text-[#1A1A1A]' : 'text-white'
                }`}
              />
              <span 
                className={`hidden md:inline text-[13px] tracking-wide transition-all duration-300 ${
                  isScrolled ? 'text-[#1A1A1A]' : 'text-white'
                }`}
                style={{ fontFamily: 'Lato, sans-serif' }}
              >
                Compte
              </span>
            </button>
            <button className="group relative" aria-label="Cart">
              <ShoppingBag 
                size={20} 
                strokeWidth={1} 
                className={`transition-all duration-300 group-hover:opacity-60 ${
                  isScrolled ? 'text-[#1A1A1A]' : 'text-white'
                }`}
              />
              {cartItemsCount > 0 && (
                <span 
                  className="absolute -top-2 -right-2 w-5 h-5 bg-[#96754a] text-white rounded-full flex items-center justify-center"
                  style={{ 
                    fontFamily: 'Lato, sans-serif',
                    fontSize: '10px'
                  }}
                >
                  {cartItemsCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}