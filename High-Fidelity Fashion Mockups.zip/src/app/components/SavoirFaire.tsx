import { Hand } from 'lucide-react';

export function SavoirFaire() {
  return (
    <section className="bg-white py-32 px-8">
      <div className="container mx-auto max-w-[900px] text-center">
        {/* Icon */}
        <div className="flex justify-center mb-8">
          <Hand 
            size={48} 
            strokeWidth={0.5} 
            className="text-[#96754a]"
          />
        </div>

        <h2 
          className="text-[#1A1A1A] mb-8"
          style={{ 
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(32px, 4vw, 48px)',
            fontWeight: 400,
            letterSpacing: '0.02em',
            lineHeight: 1.3
          }}
        >
          Savoir-Faire Marocain
        </h2>
        
        <p 
          className="text-[#595959] max-w-[700px] mx-auto leading-relaxed"
          style={{ 
            fontFamily: 'Lato, sans-serif',
            fontSize: '15px',
            fontWeight: 300,
            lineHeight: 1.8
          }}
        >
          Chaque pièce de la Maison Khoub est le fruit d'un artisanat ancestral marocain. 
          Nos artisans perpétuent des techniques séculaires, travaillant des tissus nobles 
          pour créer des créations uniques qui allient tradition et modernité. 
          De Fès à Marrakech, nos ateliers célèbrent l'excellence et le luxe discret.
        </p>

        {/* Decorative Line */}
        <div className="mt-12 flex items-center justify-center gap-4">
          <div className="h-[1px] w-16 bg-[#96754a]" />
          <div className="w-2 h-2 bg-[#96754a] rotate-45" />
          <div className="h-[1px] w-16 bg-[#96754a]" />
        </div>
      </div>
    </section>
  );
}