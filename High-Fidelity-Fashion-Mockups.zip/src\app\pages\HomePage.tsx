import { Hero } from '../components/Hero';
import { Collections } from '../components/Collections';
import { SavoirFaire } from '../components/SavoirFaire';
import { Product } from '../data/products';
import { Link } from 'react-router-dom';

interface HomePageProps {
    products: Product[];
    onProductClick: (product: Product) => void;
    onScrollToProducts: () => void;
}

export function HomePage({ products, onProductClick, onScrollToProducts }: HomePageProps) {
    const featuredProducts = products.filter(p => p.isFeatured).slice(0, 4);

    return (
        <>
            <Hero onCTAClick={onScrollToProducts} />

            {/* New Arrivals Slider */}
            <section className="py-20 bg-[#FBF7F0]">
                <div className="container mx-auto px-8">
                    <div className="flex justify-between items-end mb-12">
                        <h2 className="text-3xl text-[#2A2624]" style={{ fontFamily: 'Playfair Display, serif' }}>Nouveautés</h2>
                        <Link to="/collections/all" className="text-sm text-[#96754a] border-b border-[#96754a] pb-1 uppercase tracking-widest hover:text-[#7d6240]">
                            Tout voir
                        </Link>
                    </div>

                    {/* H-Scroll Slider */}
                    <div className="flex gap-8 overflow-x-auto pb-8 snap-x">
                        {featuredProducts.map((product) => (
                            <div key={product.id} className="min-w-[280px] md:min-w-[320px] snap-start group cursor-pointer" onClick={() => onProductClick(product)}>
                                <div className="aspect-[3/4] overflow-hidden mb-4 bg-[#F2EBE3] relative">
                                    <img
                                        src={product.image}
                                        alt={product.name}
                                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                                    />
                                    {/* Quick overlay */}
                                    <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span className="text-white text-xs uppercase tracking-widest">Voir le produit</span>
                                    </div>
                                </div>
                                <h3 className="text-[#2A2624] text-lg font-medium" style={{ fontFamily: 'Playfair Display, serif' }}>{product.name}</h3>
                                <p className="text-[#96754a] text-sm mt-1">{product.price.toLocaleString('fr-MA')} MAD</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            <Collections />

            {/* Immersion Banner - Signature */}
            <section className="w-full h-[60vh] relative flex items-center justify-center bg-fixed bg-center bg-cover" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&q=80&w=1920")' }}>
                <div className="absolute inset-0 bg-black/40"></div>
                <div className="relative z-10 text-center text-white px-4">
                    <p className="text-sm uppercase tracking-[0.3em] mb-4">Edition Limitée</p>
                    <h2 className="text-4xl md:text-6xl mb-8" style={{ fontFamily: 'Playfair Display, serif' }}>Collection Signature</h2>
                    <p className="text-lg md:text-xl font-light mb-10 max-w-2xl mx-auto opacity-90">L'Art de l'Authenticité. Des pièces uniques brodées main pour vos occasions les plus précieuses.</p>
                    <Link
                        to="/collections/signature"
                        className="inline-block border border-white px-10 py-4 uppercase tracking-widest text-sm hover:bg-white hover:text-[#1A1A1A] transition-all duration-300"
                    >
                        Découvrir
                    </Link>
                </div>
            </section>

            <SavoirFaire />
        </>
    );
}
